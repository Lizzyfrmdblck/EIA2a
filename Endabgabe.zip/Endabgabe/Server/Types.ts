interface AssocStringString {
    [key: string]: string;
}

interface PlayerData {
    name: string;
    playerscore: number;
}